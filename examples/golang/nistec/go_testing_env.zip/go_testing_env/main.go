package main

import (
	"go_testing_env/nistec"
)

func main() {
	in1 := new(nistec.P256Element)
	in2 := new(nistec.P256Element)
	var cond int
	res := new(nistec.P256Element)
	nistec.P256FromMont(res, in1)
	nistec.P256NegCond(in1, cond)
	nistec.P256Mul(res, in1, in2)
	nistec.P256Sqr(res, in1, 1)
	resPoint := new(nistec.P256Point)
	in1Point := new(nistec.P256Point)
	in2Point := new(nistec.P256Point)
	in2AffinePoint := new(nistec.P256AffinePoint)
	var sign, sel, zero int

	// Point addition with an affine point and constant time conditions.
	// If zero is 0, sets res = in2. If sel is 0, sets res = in1.
	// If sign is not 0, sets res = in1 + -in2. Otherwise, sets res = in1 + in2
	nistec.P256PointAddAffineAsm(resPoint, in1Point, in2AffinePoint, sign, sel, zero)

	// Point addition. Sets res = in1 + in2. Returns one if the two input points
	// were equal and zero otherwise. If in1 or in2 are the point at infinity, res
	// and the return value are undefined.
	nistec.P256PointAddAsm(resPoint, in1Point, in2Point)

	// Point doubling. Sets res = in + in. in can be the point at infinity.
	nistec.P256PointDoubleAsm(resPoint, in1Point)
}
