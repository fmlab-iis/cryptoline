#ifndef SI_GMP_H
#define SI_GMP_H

# include "gmp.h"

#endif /* SI_GMP_H */
