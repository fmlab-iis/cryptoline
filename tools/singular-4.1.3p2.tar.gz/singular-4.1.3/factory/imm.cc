/* emacs edit mode for this file is -*- C++ -*- */

//{{{ docu
//
// imm.cc - some special implementations of immediate functions
//   for some special platforms.
//
// Hierarchy: basic, arithmetic
//
//}}}


#include "config.h"


#include "imm.h"

