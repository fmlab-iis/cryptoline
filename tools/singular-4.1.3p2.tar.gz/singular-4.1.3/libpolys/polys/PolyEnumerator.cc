



#include "misc/auxiliary.h"

#include "PolyEnumerator.h"

const spolyrec CBasePolyEnumerator::m_prevposition_struct = {}; // it is assumed to zero-out all of the struct!
