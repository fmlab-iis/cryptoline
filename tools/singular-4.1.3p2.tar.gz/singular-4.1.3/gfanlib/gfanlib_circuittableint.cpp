/*
 * gfanlib_circuittableint.cpp
 *
 *  Created on: Apr 10, 2016
 *      Author: anders
 */

#include "gfanlib_circuittableint.h"

namespace gfan{
INST_VAR MVMachineIntegerOverflowType MVMachineIntegerOverflow;
}
